# NavigationDrawer
Android Application using JAVA which have a Navigation Drawer along with four different fragments and two activities. This App navigates the user to the desired fragment/activity, which the uses chooses.
![Screenshot_20210123-221958](https://user-images.githubusercontent.com/64889275/105608321-58873e00-5dc9-11eb-84e0-97e748e535d9.png)
![Screenshot_20210123-222003](https://user-images.githubusercontent.com/64889275/105608324-5ae99800-5dc9-11eb-91e7-97fe5f95b4eb.png)
![Screenshot_20210123-222008](https://user-images.githubusercontent.com/64889275/105608325-5cb35b80-5dc9-11eb-96bc-307151697d30.png)
